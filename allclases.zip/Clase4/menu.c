#include <stdio.h>
void main(){
    int opcion=0;
    
    while(opcion != 5){
        printf("Introduce una opcion \n");
        printf("Opcion 1: Torres de Hanoi\n");
        printf("Opcion 2: El Lobo, Obeja y Maiz\n");
        printf("Opcion 3: Antro\n");
        printf("Opcion 4: Impuestos\n");
        printf("Opcion 5: Salir \n");
        printf("\n\n");

        scanf("%d", &opcion);

        if(opcion == 1){
            //Codigo de Hanoi
        }
    }

    printf("Sali del ciclo");   
}