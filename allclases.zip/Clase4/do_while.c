#include <stdio.h>

void main(){
    int cont = 1;

    do{
        printf("%d \n", cont);
    } while(++cont<=10);
}
