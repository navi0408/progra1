#include<stdio.h>

void main(){

    int y[10];

    for(int i = 0;i<10;i++){
        y[i]=i;
    }
    for(int i =0;i<10;i++){
        printf("%d\n",y[i]);
    }
}