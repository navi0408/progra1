#include<stdio.h>
#include<string.h>

void main(){
    /*
    strlen(<cadena>) Tamaño de la cadena
    strpy(<cadena> <cadena>) Copia una cadena a Otra
    strcat(<cadena>, <cadena>) Concatena dos cadenas
    strcmp(<cadena>, <cadena>) Comparara el tamaño de las cadenas 
    */
}