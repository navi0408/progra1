#include <stdio.h>

void main(){
    for(int i = 0, j = 10; i<=j; ++i,--j){
        printf("%d, %d\n", i,j);
    }
}